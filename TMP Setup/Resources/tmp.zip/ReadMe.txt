Thank you for trying this program.

I created this program to make it easier for you to record the total playing time you spend while playing the game, it is very useful when you play Visual Novel games, because with this program you can find out your playing time easily.

If you find a bug or have a problem, you can report it to the following link:
https://github.com/KidiXDev/TrackMyPlaytime/issues

Contact me
==========
Discord Server: https://discord.gg/xWPBs55DUc

Website: https://trackmyplaytime.netlify.app/
Github Repo: https://github.com/KidiXDev/TrackMyPlaytime

If you want to donate, you can go to the following link (For now it only accepts the Indonesian region)
Saweria: https://saweria.co/kidix

~KidiXDev